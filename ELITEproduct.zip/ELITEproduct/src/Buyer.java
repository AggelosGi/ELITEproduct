
public class Buyer {

}

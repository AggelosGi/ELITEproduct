
public class Payment {

}
